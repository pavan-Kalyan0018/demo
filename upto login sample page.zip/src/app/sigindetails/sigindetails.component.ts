import { Component, OnInit, Input } from '@angular/core';

import { ProductService } from '../product.service';
import { Buyer } from '../buyer';

@Component({
  selector: 'app-sigindetails',
  templateUrl: './sigindetails.component.html',
  styleUrls: ['./sigindetails.component.css']
})
export class SigindetailsComponent implements OnInit {
 @Input()
 buyer:Buyer;
  constructor(private pService:ProductService) { }

  ngOnInit(): void {
  }

}
