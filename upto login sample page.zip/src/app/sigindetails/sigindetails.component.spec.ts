import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SigindetailsComponent } from './sigindetails.component';

describe('SigindetailsComponent', () => {
  let component: SigindetailsComponent;
  let fixture: ComponentFixture<SigindetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SigindetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SigindetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
