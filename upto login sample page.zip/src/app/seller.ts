export class Seller{

username : string;
password: string;
companyname:string;
gstin:number;
briefaboutcompany:string;
website:string;
emailId:string;
contactnumber:string;
address:string;

   
}






