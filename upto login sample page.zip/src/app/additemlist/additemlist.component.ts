import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-additemlist',
  templateUrl: './additemlist.component.html',
  styleUrls: ['./additemlist.component.css']
})
export class AdditemlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
