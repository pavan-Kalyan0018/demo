import { Component, OnInit, Input } from '@angular/core';

import { from } from 'rxjs';
import { Buyer } from '../buyer';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-siginform',
  templateUrl: './siginform.component.html',
  styleUrls: ['./siginform.component.css']
})
export class SiginformComponent implements OnInit {
@Input()
buyer : Buyer =new Buyer;
submitted=false;
  constructor( private pService:ProductService) { }

  ngOnInit(): void {
  }

  newSeller(): void{

    this.submitted=false;
    this.buyer=new Buyer();

 }
 
   save() {

     this.pService.createSeller(this.buyer)
     .subscribe(data =>console.log(data),error => console.log(error));
     this.buyer=new Buyer();
     
   }
   onSubmit(){

     this.submitted =true;
     this.save();

   }


}
