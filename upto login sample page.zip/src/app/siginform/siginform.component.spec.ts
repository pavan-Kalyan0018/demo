import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SiginformComponent } from './siginform.component';

describe('SiginformComponent', () => {
  let component: SiginformComponent;
  let fixture: ComponentFixture<SiginformComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SiginformComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SiginformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
